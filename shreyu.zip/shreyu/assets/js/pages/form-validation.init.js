/*
Template Name: Shreyu - Responsive Bootstrap 5 Admin Dashboard
Author: CoderThemes
Website: https://coderthemes.com/
Contact: support@coderthemes.com
File: Form Validation
*/

$(document).ready(function() {
    $('.parsley-examples').parsley();
});
